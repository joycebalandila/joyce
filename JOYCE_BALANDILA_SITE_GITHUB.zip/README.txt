JOYCE BALANDILA — Site officiel

Pour GitHub Pages :
1. Mets index.html à la racine du dépôt.
2. Mets le dossier assets à côté de index.html.
3. GitHub → Settings → Pages → Deploy from a branch → main → / (root).
4. Enregistre.

Ne renomme pas index.html.
